'use strict';

var name = '山田太郎';
var birth = new Date(1970, 5, 25);
var member = { name: name, birth: birth };

console.log(member);
