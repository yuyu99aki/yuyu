var Member = function() {};
var mem = new Member();
