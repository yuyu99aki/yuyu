import Area from './lib/Area';
console.log(Area.getTriangle(10, 5));