var str = 'WINGSプロジェクト';
console.log(str.substring(5, -2));
console.log(str.slice(5, -2));
