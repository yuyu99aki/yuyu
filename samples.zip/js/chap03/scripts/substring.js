var str = 'WINGSプロジェクト';
console.log(str.substring(8, 5));
console.log(str.slice(8, 5));
