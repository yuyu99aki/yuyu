var str = '!"#$%&()+-*/@~_|;:,.';
console.log(encodeURI(str));
console.log(encodeURIComponent(str));
