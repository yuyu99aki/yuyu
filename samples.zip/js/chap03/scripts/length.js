var msg = '𠮟る';
console.log(msg.length);
