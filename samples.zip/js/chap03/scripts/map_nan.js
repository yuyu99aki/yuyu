var m = new Map();
m.set(NaN, 'hoge');
console.log(m.get(NaN));
