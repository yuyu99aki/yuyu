var data = JSON.parse('{ "hoge": 1, "foo": 2 }');
console.log(data.hoge);
