var m = new Map();
m.set({}, 'hoge');
console.log(m.get({}));
