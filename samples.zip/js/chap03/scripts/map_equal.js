var m = new Map();
m.set('1', 'hoge');
console.log(m.get(1));
