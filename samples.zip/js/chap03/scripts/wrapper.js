var flag = new Boolean(false);

if (flag) {
  console.log('flagはtrueです！');
}