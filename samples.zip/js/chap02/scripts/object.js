var obj = { x:1, y:2, z:3 };
console.log(obj.x);
console.log(obj['x']);
