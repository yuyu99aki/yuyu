console.log('3.14E2' == 314);
console.log('0x10' == 16);
console.log('1' == 1);
