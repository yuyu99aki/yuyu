var rank = 'B';
switch(rank) {
  case 'A' :
  case 'B' :
  case 'C' :
    console.log('合格！');
    break;
  case 'D' :
    console.log('不合格...');
    break;
}
