let book = { title: 'Javaポケットリファレンス ', publish: '技術評論社' };
let { title: name, publish: company } = book;

console.log(name);
console.log(company);