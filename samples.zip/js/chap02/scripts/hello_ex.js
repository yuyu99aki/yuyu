// window.alertは、指定された文字列をダイアログ表示するための命令です。
window.alert('こんにちは、世界！');