for (var i = 1, j = 1; i < 5; i++, j++) {
  console.log('i * jは'+ i * j);
}
