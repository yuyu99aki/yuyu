var data = [ 'apple', 'orange', 'banana' ];
for (var key in data) {
  console.log(data[key]);
}