var msg = '';
msg = msg || 'こんにちは、世界！';
console.log(msg);
