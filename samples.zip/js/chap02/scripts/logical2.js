var x = 1;

if (x === 1) { console.log('こんにちは'); }
x ===1 && console.log('こんにちは');
