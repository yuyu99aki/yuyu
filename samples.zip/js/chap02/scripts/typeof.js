var num = 1;
console.log(typeof num);

var str = 'こんにちは' ;
console.log(typeof str);

var flag = true;
console.log(typeof flag);

var ary = ['JavaScript', 'Ajax', 'ASP.NET'];
console.log(typeof ary);

var obj = {x:1, y:2};
console.log(typeof obj);
