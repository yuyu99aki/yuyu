var rank = 'B';
if (rank === 'A') {
  console.log('Aランクです。');
} else if (rank === 'B') {
  console.log('Bランクです。');
} else if (rank === 'C') {
  console.log('Cランクです。');
} else {
  console.log('ランク外です。');
}
