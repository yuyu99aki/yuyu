window.alert('こんにちは、JavaScript！\n頑張って勉強しましょうね。');
