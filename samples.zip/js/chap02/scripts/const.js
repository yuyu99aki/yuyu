const TAX = 1.08;
var price = 100;
console.log(price * TAX);
