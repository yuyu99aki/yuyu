let name = '鈴木';
let str = `こんにちは、${name}さん。
今日も良い天気ですね！`;
console.log(str);
