var x = '0';
switch (x) {
  case 0 :
    console.log('0です。');
    break;
}
