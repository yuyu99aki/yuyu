'use strict';

var name = '鈴木';
var str = 'こんにちは、' + name + 'さん。\n今日も良い天気ですね！';
console.log(str);
