console.log(Math.max(15, -3, 78, 1));
console.log(Math.max([15, -3, 78, 1]));
