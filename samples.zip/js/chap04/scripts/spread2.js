console.log(Math.max.apply(null, [15, -3, 78, 1]));
