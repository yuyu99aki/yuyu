function show({name}) {
  console.log(name);
};

let member = {
  mid: 'Y0001',
  name: '山田太郎',
  address: 't_yamada@example.com'
};

show(member);
