var getTriangle = function(base, height) {
  return
  base * height / 2;
//return base * height / 2;
};

console.log('三角形の面積：' + getTriangle(5, 2));
