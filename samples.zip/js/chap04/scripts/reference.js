var value = 10;

function decrementValue(value) {
  value--;
  return value;
}

console.log(decrementValue(100));
console.log(value);
