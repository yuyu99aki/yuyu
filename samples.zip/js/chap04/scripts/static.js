console.log('三角形の面積：' + getTriangle(5, 2));

function getTriangle(base, height) {
  return base * height / 2;
}
